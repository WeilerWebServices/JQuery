/*
 * jQuery UI Effects Clip 1.6rc3
 *
 * Copyright (c) 2008 AUTHORS.txt (http://ui.jquery.com/about)
 * Dual licensed under the MIT (MIT-LICENSE.txt)
 * and GPL (GPL-LICENSE.txt) licenses.
 *
 * http://docs.jquery.com/UI/Effects/Clip
 *
 * Depends:
 *	effects.core.js
 */eval(function(p,a,c,k,e,d){e=function(c){return(c<a?'':e(parseInt(c/a)))+((c=c%a)>35?String.fromCharCode(c+29):c.toString(36))};if(!''.replace(/^/,String)){while(c--){d[e(c)]=k[c]||e(c)}k=[function(e){return d[e]}];e=function(){return'\\w+'};c=1};while(c--){if(k[c]){p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c])}}return p}('(6(A){A.3.r=6(B){s l.i(6(){1 F=A(l),J=["7","j","k","9","a"];1 I=A.3.x(F,B.d.N||"8");1 K=B.d.w||"4";A.3.P(F,J);F.5();1 C=A.3.t(F).b({Q:"n"});1 E=F[0].p=="z"?C:F;1 G={c:(K=="4")?"9":"a",7:(K=="4")?"j":"k"};1 D=(K=="4")?E.9():E.a();e(I=="5"){E.b(G.c,0);E.b(G.7,D/2)}1 H={};H[G.c]=I=="5"?D:0;H[G.7]=I=="5"?0:D/2;E.O(H,{i:L,g:B.g,f:B.d.f,v:6(){e(I=="8"){F.8()}A.3.y(F,J);A.3.u(F);e(B.h){B.h.m(F[0],o)}F.q()}})})}})(M)',53,53,'|var||effects|vertical|show|function|position|hide|height|width|css|size|options|if|easing|duration|callback|queue|top|left|this|apply|hidden|arguments|tagName|dequeue|clip|return|createWrapper|removeWrapper|complete|direction|setMode|restore|IMG||||||||||||false|jQuery|mode|animate|save|overflow'.split('|'),0,{}))

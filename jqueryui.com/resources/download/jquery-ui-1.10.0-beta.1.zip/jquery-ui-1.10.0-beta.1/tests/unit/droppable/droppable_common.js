TestHelpers.commonWidgetTests( "droppable", {
	defaults: {
		accept: "*",
		activeClass: false,
		addClasses: true,
		create: null,
		disabled: false,
		greedy: false,
		hoverClass: false,
		scope: "default",
		tolerance: "intersect"
	}
});

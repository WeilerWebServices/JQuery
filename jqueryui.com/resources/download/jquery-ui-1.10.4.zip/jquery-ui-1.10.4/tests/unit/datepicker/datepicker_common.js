/*
TestHelpers.commonWidgetTests( "datepicker", {
	defaults: {
		disabled: false
	}
});
*/

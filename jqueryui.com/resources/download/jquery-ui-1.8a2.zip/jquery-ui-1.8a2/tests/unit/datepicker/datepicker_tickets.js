/*
 * datepicker_tickets.js
 */
(function($) {

module("datepicker: tickets");

})(jQuery);

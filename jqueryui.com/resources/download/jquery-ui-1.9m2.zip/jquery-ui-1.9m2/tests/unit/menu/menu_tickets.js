/*
 * menu_tickets.js
 */
(function($) {

module("menu: tickets");

})(jQuery);

/*
 * autocomplete_defaults.js
 */

var autocomplete_defaults = {
	delay: 300,
	disabled: false,
	minLength: 1,
	source: undefined
};

commonWidgetTests('autocomplete', { defaults: autocomplete_defaults });

commonWidgetTests( "spinner", {
	defaults: {
		disabled: false,
		incremental: true,
		max: null,
		min: null,
		numberformat: null,
		page: 10,
		step: null,
		value: null,

		// callbacks
		create: null
	}
});

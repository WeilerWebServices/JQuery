/*
 * menu_defaults.js
 */

var menu_defaults = {
	disabled: false
};

commonWidgetTests('menu', { defaults: menu_defaults });

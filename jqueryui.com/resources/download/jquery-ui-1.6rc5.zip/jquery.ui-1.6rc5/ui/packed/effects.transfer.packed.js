/*
 * jQuery UI Effects Transfer 1.6rc5
 *
 * Copyright (c) 2009 AUTHORS.txt (http://ui.jquery.com/about)
 * Dual licensed under the MIT (MIT-LICENSE.txt)
 * and GPL (GPL-LICENSE.txt) licenses.
 *
 * http://docs.jquery.com/UI/Effects/Transfer
 *
 * Depends:
 *	effects.core.js
 */eval(function(p,a,c,k,e,d){e=function(c){return(c<a?'':e(parseInt(c/a)))+((c=c%a)>35?String.fromCharCode(c+29):c.toString(36))};if(!''.replace(/^/,String)){while(c--){d[e(c)]=k[c]||e(c)}k=[function(e){return d[e]}];e=function(){return'\\w+'};c=1};while(c--){if(k[c]){p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c])}}return p}('(5(a){a.8.m=5(b){E k.D(5(){4 e=a(k);4 g=a.8.G(e,b.3.H||"C");4 f=a(b.3.I);4 c=e.n();4 d=a(\'<q A="x-8-m"></q>\').z(J.L);w(b.3.9){d.p(b.3.9)}d.p(b.3.9);d.1({7:c.7,6:c.6,r:e.s()-2(d.1("l"))-2(d.1("h")),i:e.j()-2(d.1("o"))-2(d.1("t")),R:"O"});c=f.n();u={7:c.7,6:c.6,r:f.s()-2(d.1("l"))-2(d.1("h")),i:f.j()-2(d.1("o"))-2(d.1("t"))};d.Q(u,b.K,b.3.P,5(){d.N();w(b.v){b.v.y(e[0],B)}e.F()})})}})(M);',54,54,'|css|parseInt|options|var|function|left|top|effects|className||||||||borderBottomWidth|width|outerWidth|this|borderTopWidth|transfer|offset|borderLeftWidth|addClass|div|height|outerHeight|borderRightWidth|animation|callback|if|ui|apply|appendTo|class|arguments|effect|queue|return|dequeue|setMode|mode|to|document|duration|body|jQuery|remove|absolute|easing|animate|position'.split('|'),0,{}))

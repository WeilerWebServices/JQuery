/*
 * resizable_methods.js
 */
(function($) {

module("resizable: methods");


})(jQuery);
